"""Read-only same-frame geometry calibration: Siegelman10km -> previous15km arrays."""
from pathlib import Path
import importlib.util,hashlib,json
import numpy as np
from scipy.ndimage import map_coordinates
R=Path('/work/pi_nicholas_pizzo_uri_edu/pj4-optical-flow-20261110');O=R/'fig2_registration';O.mkdir(exist_ok=True)
vp=next(x for x in [R/'pipeline/vicar.py',R/'archive_source/src/jiram_catalog/vicar.py'] if x.exists());spec=importlib.util.spec_from_file_location('vicar',vp);vicar=importlib.util.module_from_spec(spec);spec.loader.exec_module(vicar)
records=[]
def load(p):
 im,h=vicar.read_vicar(p);return np.squeeze(im),h
def centroid(im):
 m=np.isfinite(im)&(im>0);rr=m.sum(1);cc=m.sum(0);n=m.sum();return [float(np.dot(np.arange(len(rr)),rr)/n),float(np.dot(np.arange(len(cc)),cc)/n)]
for p in sorted((R/'fig2_reference_inputs/mapped_brightness').glob('n0??.map')):
 old=R/'inputs'/p.name
 if not old.exists():continue
 a,ha=load(p);b,hb=load(old);assert ha.get('PRODUCT_ID')==hb.get('PRODUCT_ID'),p
 records.append(dict(file=p.name,new_centroid=centroid(a),old_centroid=centroid(b),touches_raster_edge=bool(np.any(a[[0,-1],:]>0) or np.any(a[:,[0,-1]]>0) or np.any(b[[0,-1],:]>0) or np.any(b[:,[0,-1]]>0)),new_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),old_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),new_label={k:ha.get(k) for k in ['PRODUCT_ID','NL','NS','MPS','MPOX','MPOY','DU']},old_label={k:hb.get(k) for k in ['PRODUCT_ID','NL','NS','MPS','MPOX','MPOY','DU']}))
assert len(records)==48,len(records)
x=np.array([r['new_centroid'] for r in records]);y=np.array([r['old_centroid'] for r in records]);train=np.array([not r['file'].startswith('n02') for r in records]);design=np.c_[x,np.ones(len(x))];eligible=np.array([not r['touches_raster_edge'] for r in records]);assert eligible.sum()>=12
def fit(mask):
 c=np.linalg.lstsq(design[mask],y[mask],rcond=None)[0];pred=design@c;err=pred-y;return c,dict(matrix=c[:2].T.tolist(),offset=c[2].tolist(),all_vector_RMS_px=float(np.sqrt(np.mean(np.sum(err**2,axis=1)))),heldout_n02_vector_RMS_px=float(np.sqrt(np.mean(np.sum(err[~train]**2,axis=1)))),singular_values=np.linalg.svd(c[:2],compute_uv=False).tolist(),maximum_centroid_residual_px=float(np.max(np.linalg.norm(err,axis=1))))
_,train_rec=fit(train&eligible);coef,all_rec=fit(eligible);M=coef[:2].T;shift=coef[2];radiance=[]
for name in ['n01a.map','n02a.map','n02f.map','n02h.map','n03l.map']:
 a,_=load(R/'fig2_reference_inputs/mapped_brightness'/name);b,_=load(R/'inputs'/name);rr,cc=np.nonzero((a[::3,::3]>0)&np.isfinite(a[::3,::3]));rr=rr*3;cc=cc*3;p=M@np.stack([rr,cc])+shift[:,None];bv=map_coordinates(b.astype(float),p,order=1,mode='constant',cval=0);bm=map_coordinates((b>0).astype(float),p,order=1,mode='constant',cval=0);keep=(bm>.999)&np.isfinite(bv);av=a[rr,cc];radiance.append(dict(file=name,samples=int(keep.sum()),retained_fraction=float(keep.mean()),correlation=float(np.corrcoef(av[keep],bv[keep])[0,1]),radiance_RMS=float(np.sqrt(np.mean((av[keep]-bv[keep])**2)))))
pole15=np.array([1800.0003,1800.0131]);pole10=np.linalg.solve(M,pole15-shift);result=dict(status='measured_same_frame_transform',eligible_unclipped_frames=int(eligible.sum()),old15_row_col_from_new10_row_col=all_rec,train_excluding_n02=train_rec,new_pole_row_col=pole10.tolist(),new_effective_km_per_px=15.0046*float(np.sqrt(abs(np.linalg.det(M)))),radiance_validation=radiance,frames=records,interpretation='Array registration only; no velocity or vorticity used. All48centroids fitted, with separate36train/12heldoutcheck and full-radiance tests.')
(O/'grid10_to_grid15.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='frames'},indent=2))
