"""Register Figure 2 tau ONLY to independently georeferenced published n02 radiance.
Never uses either measured or inferred vorticity to fit the geometry.
Run on a compute node (16 GB and 8 CPUs suggested) with an existing NumPy/SciPy environment.
"""
from pathlib import Path
import argparse,json,hashlib,sys,importlib.util
import numpy as np
from scipy.ndimage import map_coordinates,gaussian_filter
from scipy.signal import fftconvolve
from scipy.optimize import least_squares
p=argparse.ArgumentParser();p.add_argument('--root',default='/work/pi_nicholas_pizzo_uri_edu/pj4-optical-flow-20261110');p.add_argument('--template',required=True);p.add_argument('--out');p.add_argument('--input-dir');a=p.parse_args();R=Path(a.root);O=Path(a.out) if a.out else R/'fig2_registration';O.mkdir(exist_ok=True,parents=True);I=Path(a.input_dir) if a.input_dir else R/'fig2_reference_inputs/mapped_brightness'
vp=next(x for x in [R/'pipeline/vicar.py',R/'archive_source/src/jiram_catalog/vicar.py',R/'native_pipeline/vicar.py'] if x.exists());spec=importlib.util.spec_from_file_location('vicar',vp);vicar=importlib.util.module_from_spec(spec);spec.loader.exec_module(vicar)
records=[];total=None;count=None
for f in sorted(I.glob('n02?.map')):
 im,label=vicar.read_vicar(f);im=np.squeeze(im).astype(np.float64);good=np.isfinite(im)&(im>0)
 if total is None:total=np.zeros_like(im);count=np.zeros(im.shape,np.int16)
 assert total.shape==im.shape
 total+=np.where(good,im,0);count+=good
 digest=hashlib.sha256(f.read_bytes()).hexdigest();old=R/'inputs'/f.name
 records.append(dict(file=str(f),sha256=digest,identical_to_previous_input=old.exists() and hashlib.sha256(old.read_bytes()).hexdigest()==digest,label={k:label.get(k) for k in ['NL','NS','MPS','MPOX','MPOY','DU','PRODUCT_ID','IMAGE_TIME']}))
assert len(records)==12,len(records)
valid=count>0;rad=np.divide(total,count,out=np.full_like(total,np.nan),where=valid);tau=np.where(valid,-np.log10(rad),0)
# Mild symmetric radiance smoothing solely for geometric registration, not science comparison.
w=gaussian_filter(valid.astype(float),2);source=np.divide(gaussian_filter(tau,2),w,out=np.zeros_like(tau),where=w>0);source_valid=w>.999
with np.load(a.template) as z:target=z['values'].copy();target_valid=z['valid'].copy()&~z['saturation'].copy()
target_valid &= np.isfinite(target)
H,W=target.shape
center=np.array([(H-1)/2,(W-1)/2]);Y,X=np.indices(target.shape)

def rotation(angle,flip):
 theta=np.radians(angle);c,s=np.cos(theta),np.sin(theta)
 return np.array([[c,-s],[s,c]])@np.diag([1,-1 if flip else 1])

def corr(A,B):return float(np.corrcoef(A,B)[0,1])
step=4;S=source[::step,::step];SM=source_valid[::step,::step].astype(float);S=S*SM

def search(job):
 scale,angle,flip=job;A=rotation(angle,flip);corners=np.array([[0,0],[H-1,0],[0,W-1],[H-1,W-1]])-center;bounds=corners@A.T;lo=bounds.min(0);hi=bounds.max(0)
 yy=np.arange(lo[0],hi[0],step/scale);xx=np.arange(lo[1],hi[1],step/scale);qy,qx=np.meshgrid(yy,xx,indexing='ij');coords=np.array([qy,qx]).reshape(2,-1);orig=A.T@coords+center[:,None];shape=qy.shape
 T=map_coordinates(np.where(target_valid,target,0),orig,order=1,mode='constant',cval=0).reshape(shape);TM=(map_coordinates(target_valid.astype(float),orig,order=1,mode='constant',cval=0).reshape(shape)>.999).astype(float);T*=TM
 if any(n>=m for n,m in zip(T.shape,S.shape)):return dict(scale=scale,angle_deg=angle,flip=flip,correlation=-1)
 def cc(s,t):return fftconvolve(s,t[::-1,::-1],mode='valid')
 n=cc(SM,TM);ss=cc(S,TM);tt=cc(SM,T);cross=cc(S,T);ss2=cc(S*S,TM);tt2=cc(SM,T*T)
 with np.errstate(divide='ignore',invalid='ignore'):
  C=(cross-ss*tt/n)/np.sqrt(np.maximum(0,ss2-ss*ss/n)*np.maximum(0,tt2-tt*tt/n));C[(n<.97*TM.sum())|~np.isfinite(C)]=-np.inf
 iy,ix=np.unravel_index(np.argmax(C),C.shape);score=float(C[iy,ix]);csrc=np.array([iy,ix])*step-scale*lo
 return dict(scale=float(scale),angle_deg=float(angle),flip=bool(flip),row=float(csrc[0]),col=float(csrc[1]),correlation=score)

from concurrent.futures import ProcessPoolExecutor
import multiprocessing,os
workers=min(8,int(os.environ.get('SLURM_CPUS_PER_TASK','1')))
jobs=[(s,angle,flip) for angle in range(0,360,10) for flip in [False,True] for s in [1.90,2.0,2.10]]
with ProcessPoolExecutor(max_workers=workers,mp_context=multiprocessing.get_context('fork')) as pool:trials=list(pool.map(search,jobs))
best=max(trials,key=lambda r:r['correlation']);print('BEST COARSE',best,flush=True);assert np.isfinite(best['correlation']) and best['correlation']>0,best
jobs=[(float(scale),float(angle),best['flip']) for angle in np.arange(best['angle_deg']-10,best['angle_deg']+10.01,2) for scale in np.linspace(best['scale']-.08,best['scale']+.08,17)]
with ProcessPoolExecutor(max_workers=workers,mp_context=multiprocessing.get_context('fork')) as pool:trials+=list(pool.map(search,jobs))
best=max(trials,key=lambda r:r['correlation']);print('BEST REFINED',best,flush=True)
sample=target_valid&(Y%4==0)&(X%4==0);yy=Y[sample].astype(float);xx=X[sample].astype(float);tt=target[sample];coords=np.stack([yy,xx])-center[:,None];yc=(yy-yy.mean())/max(target.shape);xc=(xx-xx.mean())/max(target.shape)
train=((yy//96+xx//96)%2)==0

def evaluate(par):
 row,col,scale,angle,gain,offset,py,px=par;position=np.array([row,col])[:,None]+scale*(rotation(angle,best['flip'])@coords);v=map_coordinates(source,position,order=1,mode='constant',cval=0);w=map_coordinates(source_valid.astype(float),position,order=1,mode='constant',cval=0);return gain*v+offset+py*yc+px*xc,w
geo=np.array([best['row'],best['col'],best['scale'],best['angle_deg']]);positions=geo[:2,None]+geo[2]*(rotation(geo[3],best['flip'])@coords);sv=map_coordinates(source,positions,order=1);design=np.c_[sv,np.ones(len(tt)),yc,xc];nuis=np.linalg.lstsq(design[train],tt[train],rcond=None)[0];x0=np.r_[geo,nuis];initial_valid=map_coordinates(source_valid.astype(float),positions,order=1)>.999;train &=initial_valid
res=least_squares(lambda q:(evaluate(q)[0]-tt)[train],x0,bounds=(np.r_[x0[:2]-20,x0[2]-.05,x0[3]-3,-np.inf*np.ones(4)],np.r_[x0[:2]+20,x0[2]+.05,x0[3]+3,np.inf*np.ones(4)]),loss='soft_l1',f_scale=.03,max_nfev=150,diff_step=1e-5)
fitted,valid_fit=evaluate(res.x);keep=initial_valid&(valid_fit>.999);holdout=keep&~train;train_keep=keep&train;r0,c0,scale,angle=res.x[:4];matrix=scale*rotation(angle,best['flip']);offset=np.array([r0,c0])-matrix@center
result=dict(status='radiance_registration_measured',target=str(a.template),target_sha256=hashlib.sha256(Path(a.template).read_bytes()).hexdigest(),target_shape=[H,W],inputs=records,mosaic='Equal mean of positive finite n02a-l radiance; zero footprint excluded',initial_best=best,transform=dict(source_row_col_from_target_row_col_matrix=matrix.tolist(),source_row_col_offset=offset.tolist(),angle_deg=float(angle),reflection_columns=best['flip'],uniform_scale_source_pixels_per_pdf_pixel=float(scale)),fit_parameters=res.x.tolist(),fit_success=bool(res.success),train_correlation=corr(tt[train_keep],fitted[train_keep]),holdout_correlation=corr(tt[holdout],fitted[holdout]),holdout_RMS_tau=float(np.sqrt(np.mean((tt[holdout]-fitted[holdout])**2))),holdout_n=int(holdout.sum()),all_valid_fraction=float(keep.mean()),geography='Source is actual10km supplement. Compose this transform with independently measured10km-to15km same-frame radiance transform and PAPER_GRID. Neither reference nor new vorticity enters registration.',limitations='PDF tau digitization and source mosaic construction can differ. Shared scalar brightness gain/offset/plane are registration nuisances, not modified scientific radiance or SQG calibration.',coarse_trials=trials)
# Preserve original (not nuisance-adjusted) radiance on both the PDF raster and
# an aligned lattice with one native10km source-pixel spacing. All stays on Unity.
fullcoords=np.stack([Y.ravel(),X.ravel()]);position=matrix@fullcoords+offset[:,None]
raw_image=np.where(valid,rad,0);pdf_rad=map_coordinates(raw_image,position,order=1).reshape(target.shape);pdf_mask=(map_coordinates(valid.astype(float),position,order=1).reshape(target.shape)>.999)&(pdf_rad>0);pdf_rad=np.where(pdf_mask,pdf_rad,np.nan)
ay=np.arange(0,H-1+1e-8,1/scale);ax=np.arange(0,W-1+1e-8,1/scale);gy,gx=np.meshgrid(ay,ax,indexing='ij');analysis_coords=matrix@np.stack([gy.ravel(),gx.ravel()])+offset[:,None];analysis_shape=gy.shape
analysis_rad=map_coordinates(raw_image,analysis_coords,order=1).reshape(analysis_shape);analysis_mask=(map_coordinates(valid.astype(float),analysis_coords,order=1).reshape(analysis_shape)>.999)&(analysis_rad>0);analysis_rad=np.where(analysis_mask,analysis_rad,np.nan)
np.savez_compressed(O/'aligned_n02_radiance.npz',pdf_radiance=pdf_rad,pdf_valid=pdf_mask,pdf_source_row=position[0].reshape(target.shape),pdf_source_col=position[1].reshape(target.shape),radiance_10km=analysis_rad,valid_10km=analysis_mask,source_row_10km=analysis_coords[0].reshape(analysis_shape),source_col_10km=analysis_coords[1].reshape(analysis_shape),analysis_row_to_pdf_step=1/scale,analysis_col_to_pdf_step=1/scale)
result['aligned_radiance']=dict(path=str(O/'aligned_n02_radiance.npz'),analysis_shape=list(analysis_shape),analysis_pixel_spacing_in_source_pixels=1.0,analysis_axis_steps_in_pdf_pixels=1/scale,interpretation='Original equal-mean calibrated n02radiance sampled through fitted geometry. No brightness nuisance, detrend, or vorticity fit applied. Physical km/pixel comes from grid10_to_grid15.json.')
(O/'tau_registration.json').write_text(json.dumps(result,indent=2));np.savez_compressed(O/'tau_registration_samples.npz',target_rows=yy,target_cols=xx,target_tau=tt,predicted_tau=fitted,train=train_keep,holdout=holdout)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fullcoords=np.stack([Y.ravel(),X.ravel()]);position=matrix@fullcoords+offset[:,None];v=map_coordinates(source,position,order=1).reshape(target.shape);pred=res.x[4]*v+res.x[5]+res.x[6]*(Y-yy.mean())/max(target.shape)+res.x[7]*(X-xx.mean())/max(target.shape)
fig,axes=plt.subplots(1,3,figsize=(10,8),layout='constrained');axes[0].imshow(target,cmap='bone',vmin=-.7,vmax=1);axes[1].imshow(pred,cmap='bone',vmin=-.7,vmax=1);im=axes[2].imshow(np.where(target_valid,pred-target,np.nan),cmap='RdBu_r',vmin=-.15,vmax=.15)
for ax,title in zip(axes,['Figure2 optical depth','Registered n02 radiance','Residual optical depth']):ax.set_title(title);ax.set_axis_off()
fig.colorbar(im,ax=axes[2],shrink=.5);fig.suptitle('Radiance-only geographic registration; held-out r='+str(round(result['holdout_correlation'],4)));fig.savefig(O/'tau_registration.png',dpi=160)
print('FINAL',json.dumps({k:v for k,v in result.items() if k not in ['inputs','coarse_trials']},indent=2),flush=True)
