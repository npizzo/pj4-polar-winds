from pathlib import Path
import sys,json
import numpy as np,pandas as pd
from scipy.ndimage import map_coordinates
R=Path('/work/pi_nicholas_pizzo_uri_edu/pj4-optical-flow-20261110');O=R/'fig2_author_comparison';O.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'native_pipeline'));import polar_grid as M
sys.path.insert(0,str(R/'fig2_reference_inputs'));import reconstruct_reference as REF
G=dict(np.load(R/'fig2_registration/author_grid_n02_radiance.npz'));pos=np.array([G['source_row_10km'],G['source_col_10km']]);h=10000.;shape=pos.shape[1:]
cal=json.loads((R/'fig2_registration/grid10_to_grid15.json').read_text());A=np.array(cal['old15_row_col_from_new10_row_col']['matrix']);off=np.array(cal['old15_row_col_from_new10_row_col']['offset']);p15=(A@pos.reshape(2,-1)+off[:,None]).reshape(2,*shape)
x=(p15[1]-1800.0131)*15.0046;y=(1800.0003-p15[0])*15.0046;rho=np.hypot(x,y);sq=(rho/66854)**2/(1+rho**2*(1/66854**2-1/71492**2));lat=90-np.degrees(np.arcsin(np.sqrt(sq)));lon=np.mod(90.0009+np.degrees(np.arctan2(y,x)),360);lam=np.radians(lon)
pg=np.arctan((M.A/M.C)**2*np.tan(np.radians(lat)));rn=M.rho_of_latg(pg);X=rn*np.cos(lam);Y=rn*np.sin(lam)
Q,geometry=REF.target_basis(pos[0],pos[1],10000,h)
def sample(path,cols):
 d=pd.read_parquet(path);lo=np.array([d.ix.min(),d.iy.min()]);hi=np.array([d.ix.max(),d.iy.max()]);q=np.stack([X/150-.5-lo[0],Y/150-.5-lo[1]]);out={}
 for col in cols:
  g=np.full(tuple(hi-lo+1),np.nan);g[d.ix-lo[0],d.iy-lo[1]]=d[col];valid=np.isfinite(g);z=map_coordinates(np.where(valid,g,0),q,order=1,mode='constant',cval=0);w=map_coordinates(valid.astype(float),q,order=1,mode='constant',cval=0);out[col]=np.where(w>.999,z,np.nan)
 return out
N={};tau=np.where(G['valid_10km'],-np.log10(G['radiance_10km']),np.nan);tau=REF._filled(tau,np.isfinite(tau))
for order,name in [(2,'ours'),(1,'affine')]:
 d=sample(R/f'native_results/products/fields_o{order}_N_all_L150.parquet',['zeta','U','V']);N[name]=d['zeta']
 east=-d['U']*np.sin(lam)+d['V']*np.cos(lam);north=-d['U']*np.cos(lam)-d['V']*np.sin(lam)
 # Exact oblate orthographic Jacobian: map projection of physical east/north tangent vectors.
 bx=-east*np.sin(lam)-north*np.sin(pg)*np.cos(lam);by=east*np.cos(lam)-north*np.sin(pg)*np.sin(lam);l0=np.radians(90.0009);su=bx*np.cos(l0)+by*np.sin(l0);sv=-bx*np.sin(l0)+by*np.cos(l0);u=Q[0,0]*su+Q[1,0]*sv;v=Q[0,1]*su+Q[1,1]*sv;valid=np.isfinite(u)&np.isfinite(v);uf=REF._filled(u,valid);vf=REF._filled(v,valid)
 for mode in ['global_mean','separable_mean']:
  z=REF.spectral_diagnostics(uf,vf,tau,h,physical_orientation=geometry['physical_coordinate_orientation'],detrend_mode=mode)['zeta'];N[name+'_projected_'+mode]=z
 N[name+'_velocity_support']=valid
 print('native',name,float(np.isfinite(d['zeta']).mean()),flush=True)
N['window']=sample(R/'fig2_analysis/fields_o2_window_all_L150.parquet',['zeta'])['zeta'];N.update(source_row=pos[0],source_col=pos[1],lat_deg=lat,lon_east_deg=lon,x_native_km=X,y_native_km=Y,spacing_m=h)
np.savez_compressed(O/'geographic_samples.npz',**N)
F=REF.reconstruct_reference(R,pos[0],pos[1],target_spacing_m=h,include_separable_sensitivity=True)
(O/'reference_metadata.json').write_text(json.dumps(F['metadata'],indent=2));np.savez_compressed(O/'reference_arrays.npz',**{k:v for k,v in F.items() if isinstance(v,np.ndarray)})
# Digitize each panel with its own independent PDF axis calibration.
axes=json.loads((R/'fig2_registration/pdf_axis_geometry.json').read_text())['zeta']['raster_center_to_10km'];q=np.array([(G['figure_y_10km']-axes['y_intercept'])/axes['y_per_row'],(G['figure_x_10km']-axes['x_intercept'])/axes['x_per_col']]);D=dict(np.load(R/'fig2_registration/fig2_zeta_digitized.npz'));valid=D['valid']&~D['saturation'];values=map_coordinates(D['values'],q,order=1,mode='constant',cval=np.nan);mask=map_coordinates(valid.astype(float),q,order=1,mode='constant',cval=0)>.999;np.savez_compressed(O/'fig2_zeta_on_author_grid.npz',values=values,valid=mask,saturation=np.zeros(shape,bool))
(O/'author_processing.json').write_text(json.dumps(dict(shape=shape,nominal_spacing_m=h,measured_axis_spacing_km=G['measured_axis_spacings_km'].tolist(),native_projected_curl='Native median physical U,V bilinearly interpolated, converted to east/north, pushed through exact orthographic tangent Jacobian, rotated into author plane, mirrored/detrended and filtered identically to reference. Full original physical scalar also retained.',detrending='Separable-mean sensitivity supported by independent optical-depth reproduction; global-mean Methods interpretation retained.',all_geometry_frozen=True),indent=2));print('AUTHOR GRID COMPLETE',flush=True)
