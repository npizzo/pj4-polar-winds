"""Frozen geometry, fixed SQG amplitude, spatially blocked descriptive comparisons."""
from pathlib import Path
import sys,json
import numpy as np,pandas as pd
from scipy.ndimage import distance_transform_edt
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path('/work/pi_nicholas_pizzo_uri_edu/pj4-optical-flow-20261110');O=R/'fig2_author_comparison';sys.path.insert(0,str(R/'fig2_reference_inputs'));import reconstruct_reference as REF
N=dict(np.load(O/'geographic_samples.npz'));F=dict(np.load(O/'reference_arrays.npz'));D=dict(np.load(O/'fig2_zeta_on_author_grid.npz'));h=float(N['spacing_m']);shape=N['ours'].shape;rr,cc=np.indices(shape);Y=(shape[0]-1-rr)*h/1e6;X=cc*h/1e6
edge=np.minimum.reduce([rr,cc,shape[0]-1-rr,shape[1]-1-cc])*h/1000
native_valid=np.isfinite(N['ours']);support=native_valid&F['common_support'];interior=support&(edge>=1600)
# Plot-resolution pixels are not counted as independent wind samples. Descriptive
# summaries use approximately150km spacing; intervals resample2000km spatial blocks.
step=int(np.ceil(150000/h));stencil=(rr%step==step//2)&(cc%step==step//2)
records=[];samples={}
def metrics(name,x,y,mask):
 use=mask&stencil&np.isfinite(x)&np.isfinite(y);a=x[use];b=y[use];r=float(np.corrcoef(a,b)[0,1]);slope=float(np.cov(a,b,ddof=0)[0,1]/np.var(a));block=(np.floor(Y[use]/2)*100+np.floor(X[use]/2)).astype(int);unique=np.unique(block)
 sums=np.array([[sum(block==q),np.sum(a[block==q]),np.sum(b[block==q]),np.sum(a[block==q]**2),np.sum(b[block==q]**2),np.sum(a[block==q]*b[block==q])] for q in unique]);rng=np.random.default_rng(20261111);sb=sums[rng.integers(len(unique),size=(1000,len(unique)))].sum(1);n,sa,sb_,saa,sbb,sab=sb.T;br=(sab-sa*sb_/n)/np.sqrt(np.maximum(1e-100,(saa-sa*sa/n)*(sbb-sb_*sb_/n)))
 row=dict(comparison=name,n_spaced_samples=len(a),spatial_blocks_2000km=len(unique),correlation=r,correlation_block_p025=float(np.nanpercentile(br,2.5)),correlation_block_p975=float(np.nanpercentile(br,97.5)),rmse_s_1=float(np.sqrt(np.mean((a-b)**2))),bias_y_minus_x_s_1=float(np.mean(b-a)),slope_y_on_x=slope,sd_ratio_y_over_x=float(np.std(b)/np.std(a)));records.append(row);samples[name]=dict(x=a,y=b,block=block);return row
original_ours=N['ours'].copy();original_affine=N['affine'].copy();N['ours']=N['ours_projected_separable_mean'];N['affine']=N['affine_projected_separable_mean'];F['zeta_global_mean']=F['zeta'].copy();F['zeta']=F['zeta_separable'];F['zeta_tau']=F['zeta_tau_separable'];F['zeta_lowpass']=F['zeta_lowpass_separable'];zlow=REF.sharp_filter(N['ours'],h,high_cpkm=6e-4);alow=REF.sharp_filter(N['affine'],h,high_cpkm=6e-4)
figmask=interior&D['valid']&~D['saturation'];actual=metrics('native_quadratic_vs_Fig2b_lowpass',D['values'],zlow,figmask);recheck=metrics('reconstructed_reference_vs_Fig2b_lowpass',D['values'],F['zeta_lowpass'],figmask);metrics('native_affine_vs_Fig2b_lowpass',D['values'],alow,figmask)
BANDS={}
for lower in [800,1200]:
 band=lambda a:REF.sharp_filter(a,h,low_cpkm=6e-4,high_cpkm=1/lower)
 o,ref,sqg,af=[band(a) for a in [N['ours'],F['zeta'],F['zeta_tau'],N['affine']]];BANDS[lower]=(o,ref,sqg,af)
 for name,x,y in [('native_vs_reference_wind',ref,o),('native_vs_SQG',sqg,o),('reference_wind_vs_SQG',sqg,ref),('quadratic_vs_affine',af,o)]:metrics(f'{name}_{lower}_1667km',x,y,interior & N['affine_velocity_support'] if name=='quadratic_vs_affine' else interior)
 for margin in [1000,2400]:metrics(f'native_vs_SQG_{lower}_1667km_edge{margin}',sqg,o,support&(edge>=margin))
# Prespecified check for any influence from internal unsupported FFT fills.
invalid_distance=distance_transform_edt(support)*h/1000
for lower in [800,1200]:
 o,ref,sqg,af=BANDS[lower];metrics(f'native_vs_SQG_{lower}_1667km_gapbuffer800',sqg,o,interior&(invalid_distance>=800))
# Boundary assumption and Butterworth-convention sensitivities use the same frozen geometry.
bw3=REF.spectral_diagnostics(F['u_fft'],F['v_fft'],F['tau_fft'],h,butterworth_exponent=.5,detrend_mode='separable_mean')['zeta'];metrics('reconstructed_3dB_reference_vs_Fig2b',D['values'],REF.sharp_filter(bw3,h,high_cpkm=6e-4),figmask)
metrics('original_physical_native_vs_Fig2b_mean_only',D['values'],REF.sharp_filter(original_ours,h,high_cpkm=6e-4),figmask)
metrics('native_projected_mean_only_vs_Fig2b',D['values'],REF.sharp_filter(N['ours_projected_global_mean'],h,high_cpkm=6e-4),figmask)
metrics('reference_mean_only_vs_Fig2b',D['values'],REF.sharp_filter(F['zeta_global_mean'],h,high_cpkm=6e-4),figmask)
metrics('native_vs_reference_lowpass',F['zeta_lowpass'],zlow,interior)
metrics('reference_wind_vs_SQG_250_1667km',REF.sharp_filter(F['zeta_tau'],h,low_cpkm=6e-4,high_cpkm=4e-3),REF.sharp_filter(F['zeta'],h,low_cpkm=6e-4,high_cpkm=4e-3),interior)
periodic_low=REF.sharp_filter(N['ours'],h,high_cpkm=6e-4,mirror=False);metrics('native_periodic_vs_Fig2b_lowpass',D['values'],periodic_low,figmask)
# Temporal coverage control, deliberately not promoted to a matched-band validation.
window_mask=interior&np.isfinite(N['window']);metrics('window_vs_fullpass_unfiltered_support_control',original_ours,N['window'],window_mask)
pd.DataFrame(records).to_csv(O/'comparison_metrics.csv',index=False)
np.savez_compressed(O/'comparison_fields.npz',native_lowpass=zlow,published_Fig2b=D['values'],reference_lowpass=F['zeta_lowpass'],mask_lowpass=figmask,mask_matched=interior,native_800=BANDS[800][0],reference_800=BANDS[800][1],sqg_800=BANDS[800][2],native_1200=BANDS[1200][0],reference_1200=BANDS[1200][1],sqg_1200=BANDS[1200][2],x_1000km=X,y_1000km=Y,latitude=N['lat_deg'],longitude=N['lon_east_deg'])
plt.rcParams.update({'font.size':10,'axes.titlesize':11,'figure.facecolor':'white','savefig.facecolor':'white'})
extent=[0,shape[1]*h/1e6,0,shape[0]*h/1e6]
def mapplot(ax,a,title,lim,mask=None):
 if mask is not None:a=np.where(mask,a,np.nan)
 im=ax.imshow(a*1e4,origin='upper',extent=extent,cmap='RdBu_r',vmin=-lim,vmax=lim,interpolation='nearest');ax.set_title(title);ax.set_xlabel('x (1,000 km)');ax.set_ylabel('y (1,000 km)');return im
# Figure1 ties directly to the actual published panel, rather than reconstructed author arrays.
fig,axes=plt.subplots(1,4,figsize=(13.5,9),layout='constrained');im=mapplot(axes[0],D['values'],'Siegelman Fig. 2b\nDigitized published ζ',1);mapplot(axes[1],zlow,'Our quadratic optical flow\nPaper processing + cutoff',1,native_valid);mapplot(axes[2],F['zeta_lowpass'],'Published wind tables\nNumerical reconstruction',1,F['wind_support']);di=mapplot(axes[3],zlow-D['values'],'Our ζ − published ζ\nInterior used for statistics',.7,figmask);fig.colorbar(im,ax=axes[:3],shrink=.5,label='Vorticity (10⁻⁴ s⁻¹)');fig.colorbar(di,ax=axes[3],shrink=.5,label='Difference (10⁻⁴ s⁻¹)');fig.suptitle('PJ4 north pole: direct comparison with Figure 2b\nWavelengths >1,667 km; registration determined from brightness only',fontsize=15);fig.supxlabel(f"Our field vs Fig. 2b: r={actual['correlation']:.3f}, RMS difference={actual['rmse_s_1']*1e4:.3f} ×10⁻⁴ s⁻¹.\nFull-pass retrieval; northern pointing remains diagnostic. Matched projected curl and detrending; no vorticity fit.",fontsize=10);fig.savefig(O/'fig2_vorticity_lowpass.png',dpi=180);fig.savefig(O/'fig2_vorticity_lowpass.pdf');plt.close(fig)
# Same-band maps expose the scale limitation; never place the unmatched original b/c on equal footing.
fig,axes=plt.subplots(1,4,figsize=(13.5,9),layout='constrained');o,ref,sqg,af=BANDS[800]
im=mapplot(axes[0],o,'Our quadratic ζ\n800–1,667 km',1,native_valid);mapplot(axes[1],ref,'Published wind ζ\n800–1,667 km',1,F['wind_support']);mapplot(axes[2],sqg,'SQG ζτ from n02 radiance\n800–1,667 km; NH=36 m/s',1,F['radiance_support']);di=mapplot(axes[3],o-sqg,'Our ζ − SQG ζτ\nInterior used for statistics',1,interior);fig.colorbar(im,ax=axes[:3],shrink=.5,label='Vorticity (10⁻⁴ s⁻¹)');fig.colorbar(di,ax=axes[3],shrink=.5,label='Difference (10⁻⁴ s⁻¹)');fig.suptitle('PJ4: optical-flow vorticity versus the Figure 2c SQG construction\nSame projection, preprocessing and band; fixed SQG sign and amplitude',fontsize=15);fig.supxlabel('Diagnostic comparison: the full-pass retrieval has a variable spatial response, and is not validated throughout this band.\nFigure 2c itself includes all wavelengths below 1,667 km. These panels restrict both fields to 800–1,667 km.',fontsize=10);fig.savefig(O/'fig2_vorticity_sqg_matched.png',dpi=180);fig.savefig(O/'fig2_vorticity_sqg_matched.pdf');plt.close(fig)
fig,axes=plt.subplots(2,3,figsize=(12,8.5),layout='constrained');names=['native_quadratic_vs_Fig2b_lowpass','reconstructed_reference_vs_Fig2b_lowpass','native_vs_reference_wind_800_1667km','native_vs_SQG_800_1667km','reference_wind_vs_SQG_800_1667km','native_vs_SQG_1200_1667km'];titles=['Our ζ vs published Fig. 2b','Reference reconstruction vs Fig. 2b','Our ζ vs published wind ζ\n800–1,667 km','Our ζ vs SQG ζτ\n800–1,667 km','Published wind ζ vs SQG ζτ\n800–1,667 km','Our ζ vs SQG ζτ\n1,200–1,667 km'];xlabel=['Published Fig. 2b ζ','Published Fig. 2b ζ','Published wind ζ','SQG ζτ','SQG ζτ','SQG ζτ'];ylabel=['Our ζ','Reconstructed ζ','Our ζ','Our ζ','Published wind ζ','Our ζ']
for ax,name,title,xl,yl in zip(axes.flat,names,titles,xlabel,ylabel):
 a=samples[name]['x']*1e4;b=samples[name]['y']*1e4;lim=max(.3,np.percentile(np.abs(np.r_[a,b]),99.7));ax.hexbin(a,b,gridsize=45,mincnt=1,cmap='viridis',bins='log',extent=(-lim,lim,-lim,lim));ax.plot([-lim,lim],[-lim,lim],color='black',lw=.8,ls='--');ax.set(xlim=(-lim,lim),ylim=(-lim,lim),xlabel=xl+' (10⁻⁴ s⁻¹)',ylabel=yl+' (10⁻⁴ s⁻¹)',title=title);ax.set_aspect('equal');row=next(r for r in records if r['comparison']==name);ax.text(.03,.97,f"r={row['correlation']:.3f}\nslope={row['slope_y_on_x']:.2f}\nRMSΔ={row['rmse_s_1']*1e4:.3f}",transform=ax.transAxes,va='top',fontsize=9,bbox=dict(facecolor='white',alpha=.85,edgecolor='none'))
fig.suptitle('Pointwise comparisons after brightness-only registration',fontsize=15);fig.supxlabel('Dashed line: exact agreement. Samples spaced about 150 km; spatial dependence remains.\nMetrics exclude a 1,600 km perimeter. CSV includes 2,000 km block-bootstrap intervals and edge/boundary sensitivities.',fontsize=10);fig.savefig(O/'fig2_vorticity_scatter.png',dpi=180);fig.savefig(O/'fig2_vorticity_scatter.pdf');plt.close(fig)
status=dict(pixel_spacing_m=h,shape=shape,native_valid_fraction=float(native_valid.mean()),window_valid_fraction=float(np.isfinite(N['window']).mean()),invalid_fraction_inside_primary_region=float((~support & (edge>=1600)).sum()/max(1,(edge>=1600).sum())),reference_wind_support_fraction=float(F['wind_support'].mean()),radiance_support_fraction=float(F['radiance_support'].mean()),interior_valid_fraction=float(interior.mean()),metrics_sample_step_pixels=step,metrics_sample_spacing_km=step*h/1000,primary_edge_exclusion_km=1600,block_km=2000,processing='Paper-code interpretation: mirrored separable detrend; physical native velocities pushed through exact orthographic Jacobian before matched spectral curl. Original physical scalar/Methods-global-mean controls retained.',metrics=records,interpretation='Descriptive diagnostic, not released SQG validation: northern pointing gate failed; variable retrieval response; fullpass time window; author cropped arrays and helper code unavailable. Reference reconstruction must be checked against actual digitized Fig2b.')
(O/'comparison_summary.json').write_text(json.dumps(status,indent=2));print(json.dumps(status,indent=2),flush=True)

from PIL import Image
# The high-frequency JPEG is visual context only; its blended colours are not data.
original=np.asarray(Image.open(R/'fig2_registration/fig2_zeta_tau_rgb.png'))
fig,axes=plt.subplots(1,2,figsize=(7.5,9),layout='constrained');axes[0].imshow(original,origin='upper',extent=extent);axes[0].set_title('Published Figure 2c\nOriginal embedded image');im=mapplot(axes[1],REF.sharp_filter(F['zeta_tau'],h,low_cpkm=6e-4),'Reconstructed SQG ζτ\nFrom numerical n02 radiance',3.5,F['radiance_support']);axes[0].set(xlabel='x (1,000 km)',ylabel='y (1,000 km)');fig.colorbar(im,ax=axes,shrink=.45,label='Vorticity (10⁻⁴ s⁻¹)');fig.suptitle('Figure 2c reference check: wavelengths <1,667 km',fontsize=13);fig.supxlabel('Both use ±3.5 ×10⁻⁴ s⁻¹; missing author helpers prevent an exact reproduction.\nOriginal JPEG mixes colours at fine scales and is not used for numerical correlations.',fontsize=9);fig.savefig(O/'fig2c_reference_context.png',dpi=180);plt.close(fig)
