"""Bounded texture-only refinement of existing global radiance registration.
No wind/vorticity field is read. Preserves initial fit and evaluates held-out blocks.
"""
from pathlib import Path
import argparse,json,sys,importlib.util,hashlib
import numpy as np
from scipy.ndimage import map_coordinates,gaussian_filter,distance_transform_edt
from scipy.optimize import least_squares
from scipy.signal import detrend
p=argparse.ArgumentParser();p.add_argument('--root',default='/work/pi_nicholas_pizzo_uri_edu/pj4-optical-flow-20261110');p.add_argument('--template',required=True);p.add_argument('--initial');p.add_argument('--out');a=p.parse_args();R=Path(a.root);O=Path(a.out) if a.out else R/'fig2_registration';O.mkdir(exist_ok=True,parents=True)
initial=json.loads(Path(a.initial or O/'tau_registration.json').read_text());(O/'tau_registration_initial.json').write_text(json.dumps(initial,indent=2));M0=np.array(initial['transform']['source_row_col_from_target_row_col_matrix']);b0=np.array(initial['transform']['source_row_col_offset']);s0=np.sqrt(abs(np.linalg.det(M0)))
vp=next(x for x in [R/'pipeline/vicar.py',R/'archive_source/src/jiram_catalog/vicar.py',R/'native_pipeline/vicar.py'] if x.exists());spec=importlib.util.spec_from_file_location('vicar',vp);vicar=importlib.util.module_from_spec(spec);spec.loader.exec_module(vicar)
total=None;count=None
for f in sorted((R/'fig2_reference_inputs/mapped_brightness').glob('n02?.map')):
 im,label=vicar.read_vicar(f);im=np.squeeze(im).astype(float);good=np.isfinite(im)&(im>0)
 if total is None:total=np.zeros_like(im);count=np.zeros(im.shape,np.int16)
 total+=np.where(good,im,0);count+=good
valid=count>0;rad=np.divide(total,count,out=np.full_like(total,np.nan),where=valid);tau=np.where(valid,-np.log10(rad),0)
with np.load(a.template) as z:T=z['values'].copy();TV=z['valid'].copy()&~z['saturation'].copy()
TV &= np.isfinite(T);H,W=T.shape;Y,X=np.indices(T.shape);center=np.array([(H-1)/2,(W-1)/2]);c0=M0@center+b0
# Fill rare JPEG invalid values from nearest valid neighbor solely before smoothing.
inds=distance_transform_edt(~TV,return_distances=False,return_indices=True);Tfilled=T[tuple(inds)]
def smooth_norm(im,mask,sigma):
 w=gaussian_filter(mask.astype(float),sigma);v=gaussian_filter(np.where(mask,im,0),sigma);return np.divide(v,w,out=np.zeros_like(v),where=w>1e-8),w
small,ws=smooth_norm(tau,valid,s0);broad,wb=smooth_norm(tau,valid,16*s0);source=small-broad;SV=(ws>.999)&(wb>.99)
target=gaussian_filter(Tfilled,1)-gaussian_filter(Tfilled,16)
sample=TV&(Y%3==0)&(X%3==0)&(Y>20)&(Y<H-21)&(X>20)&(X<W-21);yy=Y[sample];xx=X[sample];coords=np.stack([yy,xx])-center[:,None];tt=target[sample];train=(yy//96+xx//96)%2==0
p0=M0@coords+c0[:,None];basevalid=map_coordinates(SV.astype(float),p0,order=1)>.999;train &=basevalid;hold=basevalid&~train

def matrix_from(q,kind):
 if kind in ['similarity','fixed_scale']:
  angle=q[3 if kind=='similarity' else 2]/1000;c,s=np.cos(angle),np.sin(angle);factor=1+q[2]/1000 if kind=='similarity' else 1.9733/s0;return M0@(factor*np.array([[c,-s],[s,c]]))
 return M0@(np.eye(2)+np.asarray(q[2:6]).reshape(2,2)/1000)

def predict(q,kind,xy=coords):
 n={'similarity':4,'fixed_scale':3,'affine':6}[kind];pos=matrix_from(q,kind)@xy+(c0+q[:2])[:,None];v=map_coordinates(source,pos,order=1,mode='constant');w=map_coordinates(SV.astype(float),pos,order=1,mode='constant');return q[n]*v+q[n+1],w,pos

def correlation(t,v):return float(np.corrcoef(t,v)[0,1])
results={};fits={}
for kind in ['similarity','fixed_scale','affine']:
 n={'similarity':4,'fixed_scale':3,'affine':6}[kind];sv=map_coordinates(source,p0,order=1);gain,off=np.linalg.lstsq(np.c_[sv[train],np.ones(train.sum())],tt[train],rcond=None)[0];q0=np.r_[np.zeros(n),gain,off];bound=np.r_[np.full(2,20.),np.full(n-2,30.),np.inf,np.inf]
 fit=least_squares(lambda q:(predict(q,kind)[0]-tt)[train],q0,bounds=(-bound,bound),loss='soft_l1',f_scale=.02,max_nfev=75,diff_step=1e-4,x_scale='jac')
 pred,w,pos=predict(fit.x,kind);mask=hold&(w>.999);M=matrix_from(fit.x,kind);b=c0+fit.x[:2]-M@center
 corner=np.array([[0,0],[H-1,0],[0,W-1],[H-1,W-1]]).T
 delta=(M-M0)@corner+(b-b0)[:,None]
 result=dict(parameters=fit.x.tolist(),fit_success=bool(fit.success),nfev=int(fit.nfev),matrix=M.tolist(),offset=b.tolist(),train_texture_r=correlation(tt[train],pred[train]),holdout_texture_r=correlation(tt[mask],pred[mask]),holdout_texture_RMS=float(np.sqrt(np.mean((tt[mask]-pred[mask])**2))),holdout_n=int(mask.sum()),singular_values=np.linalg.svd(M)[1].tolist(),max_corner_change_source_pixels=float(np.max(np.linalg.norm(delta,axis=0))))
 results[kind]=result;fits[kind]=(fit.x,M,b);print(kind,json.dumps(result),flush=True)
# Independent PDF placement/ticks establish isotropy. Affine is diagnostic only.
choose='similarity';q,M,b=fits[choose];full=np.stack([Y.ravel(),X.ravel()]);position=M@full+b[:,None];predtexture=map_coordinates(source,position,order=1).reshape(T.shape);pvalid=map_coordinates(valid.astype(float),position,order=1).reshape(T.shape)>.999
raw_image=np.where(valid,rad,0);pdf_rad=map_coordinates(raw_image,position,order=1).reshape(T.shape);pvalid &=pdf_rad>0;pdf_rad=np.where(pvalid,pdf_rad,np.nan)
rawtau=np.where(pvalid,-np.log10(np.maximum(pdf_rad,1e-100)),0)
# These are diagnostic brightness models ONLY, never used to fit geometry or science radiance.
brightness={};brightness_fields={}
for name,v in [('plane',rawtau),('sequential_linear_detrend',detrend(detrend(rawtau,axis=0),axis=1)),('separable_mean_detrend',rawtau-rawtau.mean(0)[None,:]-rawtau.mean(1)[:,None]+rawtau.mean())]:
 sm=gaussian_filter(v,1);sv=sm[sample];design=np.c_[sv,np.ones(len(tt)),(yy-center[0])/H,(xx-center[1])/H];beta=np.linalg.lstsq(design[train],T[sample][train],rcond=None)[0];p=design@beta;mask=hold&pvalid[sample];brightness[name]=dict(gain=float(beta[0]),holdout_r=correlation(T[sample][mask],p[mask]),holdout_RMS=float(np.sqrt(np.mean((T[sample][mask]-p[mask])**2))));brightness_fields[name]=beta[0]*sm+beta[1]+beta[2]*(Y-center[0])/H+beta[3]*(X-center[1])/H
# Quantify residual local geometric shifts with independently fitted texture-only patches.
patches=[]
for cy in [150,400,650,900]:
 for cx in [100,300]:
  local=(abs(yy-cy)<95)&(abs(xx-cx)<85)&basevalid;lc=coords[:,local];lt=tt[local]
  if len(lt)<100:continue
  def lp(z):
   pos=M@lc+(M@center+b+z[:2])[:,None];v=map_coordinates(source,pos,order=1);return z[2]*v+z[3]
  fit=least_squares(lambda z:lp(z)-lt,[0.,0.,1.,0.],bounds=([-10,-10,0,-np.inf],[10,10,3,np.inf]),max_nfev=35,diff_step=1e-4,loss='soft_l1',f_scale=.02)
  patches.append(dict(target_center=[cy,cx],source_shift=fit.x[:2].tolist(),shift_norm=float(np.linalg.norm(fit.x[:2])),texture_r=correlation(lt,lp(fit.x)),n=int(len(lt))))
# Export original radiance on target raster and a lattice of near10km spacing.
# Affine axes may not be orthogonal; export complete source coordinate arrays and metrics.
col_scale=np.linalg.norm(M[:,1]);row_scale=np.linalg.norm(M[:,0]);ay=np.arange(0,H-1+1e-8,1/row_scale);ax=np.arange(0,W-1+1e-8,1/col_scale);gy,gx=np.meshgrid(ay,ax,indexing='ij');apos=M@np.stack([gy.ravel(),gx.ravel()])+b[:,None];ashape=gy.shape;ar=map_coordinates(raw_image,apos,order=1).reshape(ashape);am=(map_coordinates(valid.astype(float),apos,order=1).reshape(ashape)>.999)&(ar>0);ar=np.where(am,ar,np.nan)
np.savez_compressed(O/'aligned_n02_radiance.npz',pdf_radiance=pdf_rad,pdf_valid=pvalid,pdf_source_row=position[0].reshape(T.shape),pdf_source_col=position[1].reshape(T.shape),radiance_10km=ar,valid_10km=am,source_row_10km=apos[0].reshape(ashape),source_col_10km=apos[1].reshape(ashape),analysis_row_to_pdf_step=1/row_scale,analysis_col_to_pdf_step=1/col_scale)
transform=dict(source_row_col_from_target_row_col_matrix=M.tolist(),source_row_col_offset=b.tolist(),reflection_columns=bool(np.linalg.det(M)<0),uniform_scale_source_pixels_per_pdf_pixel=float(np.sqrt(abs(np.linalg.det(M)))),row_scale_source_pixels_per_pdf_pixel=float(row_scale),column_scale_source_pixels_per_pdf_pixel=float(col_scale),axis_cosine=float(M[:,0]@M[:,1]/row_scale/col_scale))
result={**initial,'status':'radiance_texture_registration_measured','transform':transform,'refinement':dict(chosen_model=choose,models=results,brightness_diagnostics=brightness,local_patch_checks=patches,method='Initial global radiance registration, bounded 3percent similarity/affine correction using symmetric20km-to320km bandpass texture only. Fit on alternating96pixel blocks, evaluate other blocks. PDF placement independently verifies isotropy; similarity is primary. Affine is diagnostic only; fixed1.9733 sourcepx/PDFpx control comes from vector axis ticks. No wind inputs.'),'aligned_radiance':dict(path=str(O/'aligned_n02_radiance.npz'),analysis_shape=list(ashape),analysis_pixel_spacing_in_source_pixels=1.,analysis_row_to_pdf_step=float(1/row_scale),analysis_col_to_pdf_step=float(1/col_scale),axis_cosine=transform['axis_cosine'],interpretation='Unadjusted equal-mean n02 source radiance. Complete source coordinate arrays supplied; account for any nonorthogonality before FFT derivatives.')}
(O/'tau_registration.json').write_text(json.dumps(result,indent=2));np.savez_compressed(O/'tau_refinement_diagnostics.npz',target_tau=T,predicted_tau_sequential=brightness_fields['sequential_linear_detrend'],target_texture=target,predicted_texture=predtexture,valid=pvalid&TV)
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(1,4,figsize=(13,9),layout='constrained')
for ax,im,title,cm,lim in zip(axes,[T,brightness_fields['sequential_linear_detrend'],target,predtexture],['Published optical depth','Source after diagnostic detrending','Published texture','Registered source texture'],['bone','bone','RdBu_r','RdBu_r'],[(-.7,1),(-.7,1),(-.2,.2),(-.2,.2)]):ax.imshow(im,cmap=cm,vmin=lim[0],vmax=lim[1]);ax.set_title(title);ax.set_axis_off()
fig.suptitle('Radiance-only '+choose+' registration; held-out texture r='+str(round(results[choose]['holdout_texture_r'],4)));fig.savefig(O/'tau_registration_refined.png',dpi=150)
print('FINAL',json.dumps({'chosen_model':choose,'transform':transform,'brightness_diagnostics':brightness,'patches':patches,'aligned_shape':ashape}),flush=True)
