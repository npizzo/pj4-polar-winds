"""Numerical reconstruction from Siegelman's supplied 10 km products.

This is an explicit reconstruction, not a claim to reproduce missing author
NPYs/helpers bit for bit. No geographic registration, sign selection or amplitude
fit is performed here. Arrays retain top-to-bottom target raster order.

API: reconstruct_reference(root, source_row, source_col,
                           target_spacing_m=10000) -> dict
The result contains same-shaped arrays and one JSON-serializable ``metadata``.
Use ``wind_support``/``radiance_support`` for observations. ``*_fft`` arrays
include explicitly documented nearest-neighbour fills needed by the FFT;
filled pixels are never added to the observed masks.
"""
from pathlib import Path
import importlib.util
import hashlib
import json
import numpy as np
from scipy.ndimage import map_coordinates, distance_transform_edt
from scipy.spatial import cKDTree, Delaunay
from scipy.interpolate import LinearNDInterpolator
from scipy.fft import rfft2, irfft2, rfftfreq, fftfreq


def _read_vicar(root):
    candidates = [Path(root)/'pipeline/vicar.py',
                  Path(root)/'archive_source/src/jiram_catalog/vicar.py',
                  Path(root)/'native_pipeline/vicar.py',
                  Path(__file__).resolve().parents[1]/'catalog/src/jiram_catalog/vicar.py']
    path = next((p for p in candidates if p.is_file()), None)
    if path is None:
        raise FileNotFoundError('Cannot locate the audited VICAR reader')
    spec = importlib.util.spec_from_file_location('_reference_vicar', path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.read_vicar


def _products(folder, pattern):
    return sorted(p for p in Path(folder).rglob(pattern)
                  if not p.name.startswith('._') and '__MACOSX' not in p.parts)


def _filled(field, valid):
    field = np.asarray(field, dtype=float)
    valid = np.asarray(valid, dtype=bool) & np.isfinite(field)
    if not valid.any():
        raise ValueError('No valid pixels to extend for a spectral calculation')
    if valid.all():
        return field.copy()
    indices = distance_transform_edt(~valid, return_distances=False,
                                     return_indices=True)
    return np.where(valid, field, field[tuple(indices)])


def mirror_mean(field, detrend_mode='global_mean'):
    """Even mirror then global or separable mean removal.

    On this evenly mirrored domain, sequential linear detrending in x and y
    has zero fitted slopes by symmetry and equals separable mean removal.
    This does not hold for the unmirrored original image used in Figure 2a.
    """
    field = np.asarray(field, dtype=float)
    if field.ndim != 2 or not np.isfinite(field).all():
        raise ValueError('mirror_mean requires a finite 2-D field')
    wide = np.concatenate((field, field[:, ::-1]), axis=1)
    full = np.concatenate((wide, wide[::-1]), axis=0)
    if detrend_mode == 'global_mean':
        return full - full.mean()
    if detrend_mode == 'separable_mean':
        return full-full.mean(axis=0, keepdims=True)-full.mean(axis=1, keepdims=True)+full.mean()
    raise ValueError("detrend_mode must be 'global_mean' or 'separable_mean'")


def _wave(shape, spacing_m):
    kr = 2*np.pi*fftfreq(shape[0], spacing_m)[:, None]
    kc = 2*np.pi*rfftfreq(shape[1], spacing_m)[None, :]
    return kr, kc, np.hypot(kr, kc)


def sharp_filter(field, spacing_m, low_cpkm=None, high_cpkm=None,
                 valid=None, mirror=True):
    """Keep radial frequencies low<=k<=high (cycles/km); missing inputs filled.

    With only high_cpkm this is low-pass; only low_cpkm is high-pass. The
    original-sized result is finite; caller must retain its observed mask.
    This re-mirrors the cropped field, an explicit choice because the author's
    missing cut_lp/cut_hp helpers leave this detail unspecified.
    """
    a = np.asarray(field, dtype=float)
    a = _filled(a, np.isfinite(a) if valid is None else valid)
    extended = mirror_mean(a) if mirror else a-a.mean()
    _, _, k = _wave(extended.shape, spacing_m)
    cpkm = k*1000/(2*np.pi)
    keep = np.ones(k.shape, bool)
    if low_cpkm is not None:
        keep &= cpkm >= low_cpkm
    if high_cpkm is not None:
        keep &= cpkm <= high_cpkm
    out = irfft2(rfft2(extended)*keep, s=extended.shape)
    return out[:a.shape[0], :a.shape[1]]


def spectral_diagnostics(u, v, tau, spacing_m, physical_orientation=1,
                         butterworth_exponent=1.0, nh_ms=36.0,
                         detrend_mode='global_mean'):
    """Inputs finite; u right, v up; array row increases down.

    Butterworth H=[1+(250km*k_cycles)^2]**(-exponent). exponent=1 is the
    common image-filter convention; exponent=.5 gives the engineering -3dB
    convention. Neither has been fit to the observed reference. ``zeta`` is
    returned relative to north's outward normal; zeta_coordinate is explicit.
    """
    shape = np.shape(u)
    ue, ve, te = (mirror_mean(a, detrend_mode) for a in (u, v, tau))
    kr, kc, k = _wave(ue.shape, spacing_m)
    response = (1+(250000*k/(2*np.pi))**2)**(-butterworth_exponent)
    uh, vh = rfft2(ue)*response, rfft2(ve)*response
    crop = lambda a: irfft2(a, s=ue.shape)[:shape[0], :shape[1]]
    # Physical y decreases as raster row increases.
    zc = crop(1j*(kc*vh+kr*uh))
    return dict(u_filtered=crop(uh), v_filtered=crop(vh),
                zeta_coordinate=zc, zeta=physical_orientation*zc,
                divergence=crop(1j*(kc*uh-kr*vh)),
                zeta_tau=crop(-float(nh_ms)*k*rfft2(te)))


def detrend_sensitivity(u_fft, v_fft, tau_fft, spacing_m,
                        physical_orientation=1, butterworth_exponent=1.0):
    """Predetermined separable-detrend sensitivity; no registration or fit."""
    other = spectral_diagnostics(u_fft, v_fft, tau_fft, spacing_m,
                physical_orientation, butterworth_exponent,
                detrend_mode='separable_mean')
    z, t = other['zeta'], other['zeta_tau']
    return dict(zeta_separable=z, zeta_tau_separable=t,
        divergence_separable=other['divergence'],
        zeta_lowpass_separable=sharp_filter(z, spacing_m, high_cpkm=6e-4),
        zeta_tau_highpass_separable=sharp_filter(t, spacing_m, low_cpkm=6e-4),
        zeta_bandpass_separable=sharp_filter(z, spacing_m,
                                            low_cpkm=6e-4, high_cpkm=4e-3),
        zeta_tau_bandpass_separable=sharp_filter(t, spacing_m,
                                                low_cpkm=6e-4, high_cpkm=4e-3))


def target_basis(source_row, source_col, source_spacing_m, target_spacing_m):
    """Validate the supplied regular similarity and derive its vector basis."""
    row, col = np.asarray(source_row), np.asarray(source_col)
    if row.shape != col.shape or row.ndim != 2 or min(row.shape) < 3:
        raise ValueError('source_row/source_col must have equal 2-D grid shapes')
    if not (np.isfinite(row).all() and np.isfinite(col).all()):
        raise ValueError('Coordinate arrays must be finite')
    gradients = [np.diff(row, axis=0), np.diff(row, axis=1),
                 np.diff(col, axis=0), np.diff(col, axis=1)]
    values = [float(np.median(a)) for a in gradients]
    if max(np.max(np.abs(a-v)) for a, v in zip(gradients, values)) > 1e-5:
        raise ValueError('Coordinate arrays are not a regular affine lattice')
    matrix = np.asarray(values).reshape(2, 2)
    S = np.array([[0., 1.], [-1., 0.]])
    q = S@matrix@S.T
    singular = np.linalg.svd(q, compute_uv=False)
    scale = float(singular.mean())
    if abs(singular[0]/singular[1]-1) > 1e-4:
        raise ValueError('Target mapping is not an isotropic similarity')
    expected_spacing = source_spacing_m*scale
    if abs(expected_spacing/target_spacing_m-1) > .002:
        raise ValueError(f'Supplied spacing {target_spacing_m} differs from '
                         f'coordinate-implied spacing {expected_spacing}')
    Q = q/scale
    return Q, dict(source_row_col_jacobian=matrix.tolist(),
                   target_to_source_physical_rotation=Q.tolist(),
                   physical_coordinate_orientation=int(np.sign(np.linalg.det(Q))),
                   source_pixels_per_target_pixel=scale,
                   coordinate_implied_spacing_m=expected_spacing)


def reconstruct_reference(root, source_row, source_col, target_spacing_m=10000.,
                          input_dir=None, wind_position='start',
                          max_gap_grid_steps=3., butterworth_exponent=1.,
                          include_3db_sensitivity=True, source_physical_orientation=1,
                          include_separable_sensitivity=False):
    """Read all n0103 vectors/n02 maps; reconstruct on frozen supplied coordinates.

    ``wind_position='start'`` uses the TP4 template centre, the documented table
    sampling location. ``'midpoint'`` is an explicitly optional sensitivity;
    the absent author mosaic code does not establish which it used.
    No manual outlier clipping or fitted radiance gain/offset is applied.
    """
    root = Path(root)
    folder = Path(input_dir) if input_dir else root/'fig2_reference_inputs'
    read_vicar = _read_vicar(root)
    sr, sc = np.asarray(source_row, dtype=float), np.asarray(source_col, dtype=float)
    map_files = _products(folder, 'n02?.map')
    vector_files = _products(folder, 'n0103??.tp4')
    if len(map_files) != 12 or not vector_files:
        raise ValueError(f'Expected 12 n02 maps and n0103 vectors; found '
                         f'{len(map_files)}, {len(vector_files)}')
    total = count = None
    map_records = []
    for path in map_files:
        im, label = read_vicar(path)
        im = np.asarray(im).squeeze().astype(float)
        spacing = float(label['MPS'])*1000
        if total is None:
            total, count = np.zeros_like(im), np.zeros(im.shape, np.int16)
            source_spacing = spacing
        if im.shape != total.shape or spacing != source_spacing:
            raise ValueError('Map dimensions/spacing differ within n02')
        valid = np.isfinite(im)&(im > 0)
        total += np.where(valid, im, 0)
        count += valid
        map_records.append(dict(file=str(path.relative_to(folder)),
                                sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    Q, geometry = target_basis(sr, sc, source_spacing, target_spacing_m)
    mosaic = np.divide(total, count, out=np.zeros_like(total), where=count > 0)
    coords = np.array([sr, sc])
    rad = map_coordinates(mosaic, coords, order=1, mode='constant', cval=0)
    rad_support = (map_coordinates((count > 0).astype(float), coords,
                   order=1, mode='constant', cval=0) > .999)&(rad > 0)
    rad[~rad_support] = np.nan
    tau = -np.log10(rad)
    tau -= np.nanmean(tau)
    tau_fft = _filled(tau, rad_support)
    tau_fft -= tau_fft.mean()
    # Avoid retaining full 3000x3200 images while constructing the triangulation.
    map_nl = total.shape[0]
    del total, count, mosaic, im

    locations, velocities, vector_records, grids = [], [], [], []
    for path in vector_files:
        a, label = read_vicar(path)
        a = np.asarray(a, dtype=float)
        if a.ndim != 2 or a.shape[1] != 8:
            raise ValueError(f'Unexpected TP4 columns: {path}')
        a = a[np.isfinite(a).all(axis=1)]
        factor = float(label['MPS'])*1000/float(label['DT'])
        if float(label['MPS'])*1000 != source_spacing:
            raise ValueError(f'TP4 scale differs from brightness maps: {path}')
        residual = float(np.max(np.abs(a[:, 6:8]-factor*a[:, 4:6])))
        if residual > .01:
            raise ValueError(f'TP4 signed velocity convention failed: {path}, {residual}')
        if wind_position == 'start':
            xy = a[:, :2]
        elif wind_position == 'midpoint':
            xy = .5*(a[:, :2]+a[:, 2:4])
        else:
            raise ValueError("wind_position must be 'start' or 'midpoint'")
        locations.append(np.c_[map_nl-xy[:, 1], xy[:, 0]-1])
        velocities.append(a[:, 6:8])
        if 'GRID' in label:
            grids.append(float(label['GRID']))
        vector_records.append(dict(file=str(path.relative_to(folder)), rows=len(a),
            DT_s=float(label['DT']), MPS_km=float(label['MPS']),
            max_signed_column_residual_ms=residual,
            sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    points, inverse, multiplicity = np.unique(np.vstack(locations), axis=0,
                               return_inverse=True, return_counts=True)
    uv = np.vstack(velocities)
    uv = np.column_stack([np.bincount(inverse, weights=uv[:, j])/multiplicity
                          for j in range(2)])
    tree = cKDTree(points)
    grid_step = float(np.median(grids)) if grids else float(np.median(
                    tree.query(points[::max(1, len(points)//10000)], k=2)[0][:, 1]))
    if grid_step <= 0:
        raise ValueError('Cannot determine vector sampling grid step')
    query = np.c_[sr.ravel(), sc.ravel()]
    tri = Delaunay(points)
    result_uv = LinearNDInterpolator(tri, uv, fill_value=np.nan)(query)
    distance = tree.query(query, k=1)[0]
    simplex = tri.find_simplex(query)
    vertices = points[tri.simplices]
    largest_edge = np.maximum.reduce([np.linalg.norm(vertices[:, a]-vertices[:, b], axis=1)
                                      for a, b in [(0, 1), (0, 2), (1, 2)]])
    support = ((simplex >= 0)&np.isfinite(result_uv).all(axis=1)&
               (distance <= max_gap_grid_steps*grid_step)&
               (largest_edge[np.maximum(simplex, 0)] <= max_gap_grid_steps*grid_step))
    # Rows are vectors: V_target=Q.T V_source is uv_source @ Q.
    result_uv = result_uv@Q
    support = support.reshape(sr.shape)
    u, v = (result_uv[:, i].reshape(sr.shape) for i in range(2))
    u, v = np.where(support, u, np.nan), np.where(support, v, np.nan)
    u_fft, v_fft = _filled(u, support), _filled(v, support)
    orientation = source_physical_orientation*geometry['physical_coordinate_orientation']
    fields = spectral_diagnostics(u_fft, v_fft, tau_fft, target_spacing_m,
                                  orientation, butterworth_exponent)
    fields.update(u=u, v=v, u_fft=u_fft, v_fft=v_fft, tau=tau, tau_fft=tau_fft,
                  radiance=rad, radiance_support=rad_support, wind_support=support,
                  common_support=rad_support&support,
                  nearest_vector_distance_km=distance.reshape(sr.shape)*source_spacing/1000,
                  wind_support_distance_km=distance_transform_edt(
                      np.pad(support, 1, constant_values=False))[1:-1, 1:-1]*target_spacing_m/1000)
    fields['zeta_lowpass'] = sharp_filter(fields['zeta'], target_spacing_m,
                                          high_cpkm=6e-4)
    fields['zeta_tau_highpass'] = sharp_filter(fields['zeta_tau'], target_spacing_m,
                                              low_cpkm=6e-4)
    fields['zeta_bandpass'] = sharp_filter(fields['zeta'], target_spacing_m,
                                           low_cpkm=6e-4, high_cpkm=4e-3)
    fields['zeta_tau_bandpass'] = sharp_filter(fields['zeta_tau'], target_spacing_m,
                                               low_cpkm=6e-4, high_cpkm=4e-3)
    if include_3db_sensitivity:
        other = spectral_diagnostics(u_fft, v_fft, tau_fft, target_spacing_m,
                                      orientation, .5)
        fields['zeta_3db_convention'] = other['zeta']
        fields['zeta_lowpass_3db_convention'] = sharp_filter(other['zeta'],
                                            target_spacing_m, high_cpkm=6e-4)
    if include_separable_sensitivity:
        fields.update(detrend_sensitivity(u_fft, v_fft, tau_fft,
                        target_spacing_m, orientation, butterworth_exponent))
    fields['metadata'] = dict(status='reconstructed_reference_not_author_arrays',
        map_inputs=map_records, vector_inputs=vector_records, geometry=geometry,
        pixel_spacing_m=float(target_spacing_m), source_spacing_m=source_spacing,
        physical_zeta_orientation='north outward; positive cyclonic',
        source_physical_orientation=int(source_physical_orientation),
        source_vector_rows=sum(x['rows'] for x in vector_records),
        unique_vector_locations=len(points), wind_position=wind_position,
        vector_grid_step_source_pixels=grid_step, max_gap_grid_steps=max_gap_grid_steps,
        interpolation='Average exact duplicate locations; piecewise linear Delaunay; '
                      'outside hull and triangles wider than max_gap_grid_steps are unsupported.',
        n02_mosaic='Equal mean of finite positive radiance over all 12 footprints; '
                   'bilinear sampling requires all neighbouring source footprint pixels.',
        spectral_fill='Nearest supported pixel fills holes/exterior solely for FFT; '
                      'observed masks stay false. Nonlocal spectral edge contamination remains.',
        mirror='Even mirror x then y, duplicate boundary samples, global mean subtraction; '
               'crop first quadrant. Sharp filters re-mirror original-size cropped diagnostics.',
        detrend_mode='global_mean',
        separable_detrend_sensitivity_included=bool(include_separable_sensitivity),
        butterworth=dict(order=1, cutoff_wavelength_km=250,
                          amplitude_denominator_exponent=butterworth_exponent,
                          missing_helper_convention_uncertain=True),
        sqg=dict(log_base=10, N_s_inverse=.004, H0_m=9000, NH_ms=36,
                 formula='zeta_tau_hat=-36*|k_rad_per_m|*tau_hat', amplitude_fitted=False),
        support_fraction=dict(wind=float(support.mean()), radiance=float(rad_support.mean()),
                              common=float((support&rad_support).mean())),
        limitations=['Author cropped NPYs, mosaic interpolation and helper modules absent.',
                     'Nominal polar-plane curl is not the native ellipsoidal metric curl.',
                     'Start versus midpoint vector position is an explicit sensitivity.',
                     'No sign, geographic registration, or amplitude fit to vorticity.'])
    return fields


if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', required=True)
    p.add_argument('--aligned', required=True, help='aligned_n02_radiance.npz')
    p.add_argument('--out', required=True)
    p.add_argument('--pdf-grid', action='store_true')
    p.add_argument('--spacing-m', type=float, default=10000.)
    a = p.parse_args()
    with np.load(a.aligned) as z:
        prefix = 'pdf_source_' if a.pdf_grid else 'source_'
        suffix = '' if a.pdf_grid else '_10km'
        fields = reconstruct_reference(a.root, z[prefix+'row'+suffix],
                                       z[prefix+'col'+suffix], a.spacing_m)
    out = Path(a.out)
    out.parent.mkdir(exist_ok=True, parents=True)
    out.with_suffix('.json').write_text(json.dumps(fields.pop('metadata'), indent=2))
    np.savez_compressed(out, **fields)
