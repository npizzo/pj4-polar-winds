PJ4 Siegelman comparison, 11 November 2026

Open siegelman-comparison.html for methods, figures and interpretation.
Full arrays: Unity /work/pi_nicholas_pizzo_uri_edu/pj4-optical-flow-20261110/fig2_author_comparison/
Source reference inputs: sibling fig2_reference_inputs/. Native fields: sibling native_results/products/.
Primary processing uses matched projected velocity curl and separable detrending. Original physical-scalar and global-mean controls are preserved in metrics.
The publication reference reconstruction is approximate because final cropped author arrays and helper routines were not supplied. Do not interpret high-band disagreement as falsification of SQG.
The native retrieval and original frozen acceptance criteria are unchanged. Northern pointing remains diagnostic.
CSV.gz samples use a150km stencil and physical s^-1 values; masks must be applied. They are spatially dependent.
